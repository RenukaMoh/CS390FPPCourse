package lesson2;

public class Test {
    public static void main(String[] args){
    String x = null;
        System.out.println(x.length());

    }
}
