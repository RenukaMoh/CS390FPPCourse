package lesson2.charsandstrings;

public class EscapeSequence {
	public static void main(String args[]) {
		System.out.println("First line\nSecond line");
		System.out.println("A\tB\tC");
		System.out.println("\tD\tF") ;
		System.out.println("The character is "+'\u0041'); 
		System.out.println("Welcome to Java \rProgramming");
	}
}
