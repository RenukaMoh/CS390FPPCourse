package lesson2.charsandstrings;

public class TestVariables {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int x; // Declaring int variable x
		x = 10; // Assigning a value 
		int y = 20; // Declaration and Initialization
		y = y + 20;
		double day_20_temp = 34.56;
		int a = 10;
		int b = 20;
		var sum = a + b;
		System.out.println("Sum of " + a +" + " + b + " = " +sum);
	}
}
