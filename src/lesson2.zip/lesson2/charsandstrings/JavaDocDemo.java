package lesson2.charsandstrings;
/** Class: Fundamental Programming Practice  <br />
  @author "Renuka Mohanraj" <br />
  Description: (Give a brief description for your exercise) <br />
  Due: 09/06/2024 <br />
  Sign here: __________ <br />
 */
public class JavaDocDemo {
	/** The main method displays three message */
	public static void main(String[] args) {
		/*
		 * This programs explains all three
		 * types of Commandlines
		 */
		 // Use the println statements to display three messages
		// Non-executable line ignored by the compiler
	    System.out.println("Programming is fun");
	    System.out.println("Welcome to Computer Programming");
	    System.out.println("Java is a programming language");
	}
}
