package lesson2.arrays;

public class TestTypes {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// Primitive Type
		int x ;
		x = 10;
		boolean b = false;
		char c = 'a';
		char ap = 65; // a
		System.out.println("\ud835\udd6b"); 
		
		// Reference/Object type
		Integer a = 20;
		int res = a.compareTo(20);
		

	}

}
